package com.example.mpandroidchart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.mpandroidchart.charts.AnotherBarActivity;
import com.example.mpandroidchart.charts.BarChartActivity;
import com.example.mpandroidchart.charts.BarChartActivityMultiDataset;
import com.example.mpandroidchart.charts.BarChartActivitySinus;
import com.example.mpandroidchart.charts.BarChartPositiveNegative;
import com.example.mpandroidchart.charts.BubbleChartActivity;
import com.example.mpandroidchart.charts.CandleStickChartActivity;
import com.example.mpandroidchart.charts.CombinedChartActivity;
import com.example.mpandroidchart.charts.CubicLineChartActivity;
import com.example.mpandroidchart.charts.DynamicalAddingActivity;
import com.example.mpandroidchart.charts.FilledLineActivity;
import com.example.mpandroidchart.charts.HalfPieChartActivity;
import com.example.mpandroidchart.charts.HorizontalBarChartActivity;
import com.example.mpandroidchart.charts.InvertedLineChartActivity;
import com.example.mpandroidchart.charts.LineChartActivity1;
import com.example.mpandroidchart.charts.LineChartActivity2;
import com.example.mpandroidchart.charts.LineChartActivityColored;
import com.example.mpandroidchart.charts.LineChartTime;
import com.example.mpandroidchart.charts.ListViewBarChartActivity;
import com.example.mpandroidchart.charts.ListViewMultiChartActivity;
import com.example.mpandroidchart.charts.MultiLineChartActivity;
import com.example.mpandroidchart.charts.PerformanceLineChart;
import com.example.mpandroidchart.charts.PieChartActivity;
import com.example.mpandroidchart.charts.PiePolylineChartActivity;
import com.example.mpandroidchart.charts.RadarChartActivity;
import com.example.mpandroidchart.charts.RealtimeLineChartActivity;
import com.example.mpandroidchart.charts.ScatterChartActivity;
import com.example.mpandroidchart.charts.ScrollViewActivity;
import com.example.mpandroidchart.charts.SimpleChartDemo;
import com.example.mpandroidchart.charts.StackedBarActivity;
import com.example.mpandroidchart.charts.StackedBarActivityNegative;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

/**
 * Created by China_psy on 22/05/07.
 */

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("MPAndroidChart Example");
        ArrayList<ContentItem> objects = new ArrayList<>();
        objects.add(0, new ContentItem("Line Charts"));

        objects.add(1, new ContentItem("Basic", "Simple line chart."));
        objects.add(2, new ContentItem("Multiple", "Show multiple data sets."));
        objects.add(3, new ContentItem("Dual Axis", "Line chart with dual y-axes."));
        objects.add(4, new ContentItem("Inverted Axis", "Inverted y-axis."));
        objects.add(5, new ContentItem("Cubic", "Line chart with a cubic line shape."));
        objects.add(6, new ContentItem("Colorful", "Colorful line chart."));
        objects.add(7, new ContentItem("Performance", "Render 30.000 data points smoothly."));
        objects.add(8, new ContentItem("Filled", "Colored area between two lines."));

        objects.add(9, new ContentItem("Bar Charts"));

        objects.add(10, new ContentItem("Basic", "Simple bar chart."));
        objects.add(11, new ContentItem("Basic 2", "Variation of the simple bar chart."));
        objects.add(12, new ContentItem("Multiple", "Show multiple data sets."));
        objects.add(13, new ContentItem("Horizontal", "Render bar chart horizontally."));
        objects.add(14, new ContentItem("Stacked", "Stacked bar chart."));
        objects.add(15, new ContentItem("Negative", "Positive and negative values with unique colors."));
        objects.add(16, new ContentItem("Stacked 2", "Stacked bar chart with negative values."));
        objects.add(17, new ContentItem("Sine", "Sine function in bar chart format."));

        objects.add(18, new ContentItem("Pie Charts"));

        objects.add(19, new ContentItem("Basic", "Simple pie chart."));
        objects.add(20, new ContentItem("Value Lines", "Stylish lines drawn outward from slices."));
        objects.add(21, new ContentItem("Half Pie", "180° (half) pie chart."));

        objects.add(22, new ContentItem("Other Charts"));

        objects.add(23, new ContentItem("Combined Chart", "Bar and line chart together."));
        objects.add(24, new ContentItem("Scatter Plot", "Simple scatter plot."));
        objects.add(25, new ContentItem("Bubble Chart", "Simple bubble chart."));
        objects.add(26, new ContentItem("Candlestick", "Simple financial chart."));
        objects.add(27, new ContentItem("Radar Chart", "Simple web chart."));

        objects.add(28, new ContentItem("Scrolling Charts"));

        objects.add(29, new ContentItem("Multiple", "Various types of charts as fragments."));
        objects.add(30, new ContentItem("View Pager", "Swipe through different charts."));
        objects.add(31, new ContentItem("Tall Bar Chart", "Bars bigger than your screen!"));
        objects.add(32, new ContentItem("Many Bar Charts", "More bars than your screen can handle!"));

        objects.add(33, new ContentItem("Even More Line Charts"));

        objects.add(34, new ContentItem("Dynamic", "Build a line chart by adding points and sets."));
        objects.add(35, new ContentItem("Realtime", "Add data points in realtime."));
        objects.add(36, new ContentItem("Hourly", "Uses the current time to add a data point for each hour."));

        MyAdapter adapter = new MyAdapter(this, objects);

        ListView lv = findViewById(R.id.listView1);
        lv.setVerticalScrollBarEnabled(false);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(this);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        Intent i = null;

        switch (position) {
            case 1:
                i = new Intent(this, LineChartActivity1.class);
                break;
            case 2:
                i = new Intent(this, MultiLineChartActivity.class);
                break;
            case 3:
                i = new Intent(this, LineChartActivity2.class);
                break;
            case 4:
                i = new Intent(this, InvertedLineChartActivity.class);
                break;
            case 5:
                i = new Intent(this, CubicLineChartActivity.class);
                break;
            case 6:
                i = new Intent(this, LineChartActivityColored.class);
                break;
            case 7:
                i = new Intent(this, PerformanceLineChart.class);
                break;
            case 8:
                i = new Intent(this, FilledLineActivity.class);
                break;
            case 10:
                i = new Intent(this, BarChartActivity.class);
                break;
            case 11:
                i = new Intent(this, AnotherBarActivity.class);
                break;
            case 12:
                i = new Intent(this, BarChartActivityMultiDataset.class);
                break;
            case 13:
                i = new Intent(this, HorizontalBarChartActivity.class);
                break;
            case 14:
                i = new Intent(this, StackedBarActivity.class);
                break;
            case 15:
                i = new Intent(this, BarChartPositiveNegative.class);
                break;
            case 16:
                i = new Intent(this, StackedBarActivityNegative.class);
                break;
            case 17:
                i = new Intent(this, BarChartActivitySinus.class);
                break;
            case 19:
                i = new Intent(this, PieChartActivity.class);
                break;
            case 20:
                i = new Intent(this, PiePolylineChartActivity.class);
                break;
            case 21:
                i = new Intent(this, HalfPieChartActivity.class);
                break;
            case 23:
                i = new Intent(this, CombinedChartActivity.class);
                break;
            case 24:
                i = new Intent(this, ScatterChartActivity.class);
                break;
            case 25:
                i = new Intent(this, BubbleChartActivity.class);
                break;
            case 26:
                i = new Intent(this, CandleStickChartActivity.class);
                break;
            case 27:
                i = new Intent(this, RadarChartActivity.class);
                break;
            case 29:
                i = new Intent(this, ListViewMultiChartActivity.class);
                break;
            case 30:
                i = new Intent(this, SimpleChartDemo.class);
                break;
            case 31:
                i = new Intent(this, ScrollViewActivity.class);
                break;
            case 32:
                i = new Intent(this, ListViewBarChartActivity.class);
                break;
            case 34:
                i = new Intent(this, DynamicalAddingActivity.class);
                break;
            case 35:
                i = new Intent(this, RealtimeLineChartActivity.class);
                break;
            case 36:
                i = new Intent(this, LineChartTime.class);
                break;
        }
        if (i != null) startActivity(i);
        overridePendingTransition(R.anim.move_right_in_activity, R.anim.move_left_out_activity);

    }

}