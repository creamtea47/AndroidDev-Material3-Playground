package com.example.mpandroidchart.charts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.mpandroidchart.R;

public class RealmMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_realm_main);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(R.anim.move_left_in_activity, R.anim.move_right_out_activity);
    }
}